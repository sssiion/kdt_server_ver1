package com.example.KDT_bank_server_project2.chatUI;

import com.example.KDT_bank_server_project2.manager.RabbitMQ.WebSocketChatClient;

import javax.swing.*;

public class ChatUImain {
    JFrame frame;
    String localhost;
    JTextField inputid;
    JTextField inputpw;
    JLabel title;

    JButton loginbutton;

    private WebSocketChatClient webSocketClient;
    private String currentUserId;

}
