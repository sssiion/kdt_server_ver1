package com.example.KDT_bank_server_project2.manager.Service;

public class LoginService {
    private final String baseUrl = "http://localhost:8080/api";
}
