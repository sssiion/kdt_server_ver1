package com.example.KDT_bank_server_project2.manager.Repository;


import com.example.KDT_bank_server_project2.manager.Entity.ChatRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ChatRoomRepository extends JpaRepository<ChatRoom, Long> {
    ChatRoom findByroomUuid(String roomUuid);
    // 룸 UUID로 채팅방 찾기

    boolean existsByroomUuid(String roomUuid);
    //룸 UUID 존재 여부 확인

    List<ChatRoom> findByRoomNameContaining(String keyword);
    //방 이름으로 검색

    List<ChatRoom> findByCreatorId(String creatorId);
    //특정 사용자가 만든 방 목록

    Optional<ChatRoom> findByRoomName(String roomName);
    // 방이름으로 찾기
    List<ChatRoom> findBy

    @Query("SELECT cr FROM ChatRoom cr ORDER BY cr.createAt DESC")
    List<ChatRoom> findAllOrderByCreatedAtDesc();
    //최근 생성된 방 목록 (생성일 기준 내림차 순)

    @Query("SELECT COUNT(cr) FROM ChatRoom cr")
    long countChatRooms();
    // 활성 방 개수 조회
}
