package com.example.KDT_bank_server_project2.manager.Controller;

import com.example.KDT_bank_server_project2.manager.DTO.CreateRoomDto;
import com.example.KDT_bank_server_project2.manager.Entity.ChatRoom;
import com.example.KDT_bank_server_project2.manager.Repository.ChatRoomRepository;
import com.example.KDT_bank_server_project2.manager.Service.ChatRoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chatrooms")
@RequiredArgsConstructor
public class ChatRoomController {
    @Autowired
    private ChatRoomService chatRoomService;

    @PostMapping
    public ResponseEntity<?> createChatRoom(@RequestBody CreateRoomDto dto){
        ChatRoom room = chatRoomService.createRoom(dto.getRoomName(),dto.getuserId());
        return ResponseEntity.ok(room);
    }
    @GetMapping
    public ResponseEntity<?> getChatRoom(){
        return ResponseEntity.ok(chatRoomService.getAllRooms());
    }
    @GetMapping("/my")
    public ResponseEntity<?> getMyChatRoom(@RequestParam String userId ){
        List<ChatRoom> rooms = chatRoomService.getUserRooms(userId);

    }
}
