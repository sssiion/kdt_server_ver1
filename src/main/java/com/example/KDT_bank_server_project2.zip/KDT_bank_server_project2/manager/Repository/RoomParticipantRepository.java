package com.example.KDT_bank_server_project2.manager.Repository;


import com.example.KDT_bank_server_project2.manager.Entity.RoomParticipant;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository // Jpa 상속 > 인터페이스 정의로 Spring이 자동 구현체 생성, 메서드 명 보고 자동 SQL 생성
public interface RoomParticipantRepository  extends JpaRepository<RoomParticipant, Long> {

    List<RoomParticipant> findByRoomUuidAndIsActiveTrue(String roomUuid);
    // 특정 방의 활성 참가자 목록 ..> 지울까?

    List<RoomParticipant> findByUserIdAndIsActiveTrue(String userId);
    // 특정 사용자가 참가한 방 목록

    Optional<RoomParticipant> findByUserIdAndRoomUuidAndIsActiveTrue(String roomUuid,String userId);
    //특정 사용자가 특정 방에 참가 중인지 확인. ...?

    Long countByRoomUuidAndIsActiveTrue(String roomUuid);
    // 방 참가자 수

    List<RoomParticipant> findByRoomUuidOrderByJoinedAtDesc(String roomUuid);
    // 특정 방의 모든 참가 기록

    List<RoomParticipant> findeByuserIdOrderByJoinedAtAsc(String roomUuid);
    //사용자의 모든 방 참가 기록


    @Modifying
    @Transactional
    @Query("UPDATE RoomParticipant  rp SET rp.isActive = false, rp.leftAt = CURRENT_TIMESTAMP  WHERE rp.roomUuid = :roomUuid AND rp.userId = :userId")
    void leaveRoom(@Param("roomUuid")String roomUuid, @Param("userId")String userId);
    //방 나가기 처리(커스텀 쿼리)

    @Query("SELECT rp.userId FROM RoomParticipant rp WHERE rp.roomUuid = :roomUuid AND rp.isActive = true")
    List<String> findActiveParticipantsIdsByRoomUuid(@Param("roomUuid")String roomUuid);
    //방의 활성 참가자 ID 목록만 조회.



}
