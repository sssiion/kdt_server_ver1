package com.example.KDT_bank_server_project2.manager.RabbitMQ;

import com.example.KDT_bank_server_project2.manager.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

@Component
public class WebSocketEventListener {
    @Autowired
    private UserService userService;

    @EventListener
    public void handleWebSocketConnectListener(SessionConnectedEvent event) {
        String userId = getUserIdFromSession(event);
        if(userId != null){
            userService.updateOnlineStatus(userId, true);
        }
    }

    @EventListener
    public void handleWebsocketDisconnectListener(SessionDisconnectEvent event) {
        String userId = getUserIdFromSession(event);
        if(userId != null){
            userService.updateOnlineStatus(userId, false);
        }
    }
    private String getUserIdFromSession(SessionConnectedEvent event) {
        return null;
    }
}
