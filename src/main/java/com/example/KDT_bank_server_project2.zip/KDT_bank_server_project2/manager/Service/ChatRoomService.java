package com.example.KDT_bank_server_project2.manager.Service;
import lombok.RequiredArgsConstructor;
import com.example.KDT_bank_server_project2.manager.Entity.ChatRoom;
import com.example.KDT_bank_server_project2.manager.Repository.ChatRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ChatRoomService {
    @Autowired
    private ChatRoomRepository chatRoomRepository;


    public ChatRoom createRoom(String roomName, String creatorId){
        ChatRoom room = new ChatRoom(roomName, creatorId);
        return chatRoomRepository.save(room);
        // 방 생성
    }
    public List<ChatRoom> getAllRooms(){
        return chatRoomRepository.findAll();
    } // 모든 방 객체 가져오기
    public ChatRoom getRoomById(String roomId){return chatRoomRepository.}
}
