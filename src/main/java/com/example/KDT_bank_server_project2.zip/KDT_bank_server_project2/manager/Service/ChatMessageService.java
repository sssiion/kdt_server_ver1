package com.example.KDT_bank_server_project2.manager.Service;

import com.example.KDT_bank_server_project2.manager.Entity.ChatMessage;
import com.example.KDT_bank_server_project2.manager.Entity.ChatRoom;
import com.example.KDT_bank_server_project2.manager.Entity.user;
import com.example.KDT_bank_server_project2.manager.Repository.ChatMessageRepository;
import com.example.KDT_bank_server_project2.manager.Repository.ChatRoomRepository;
import com.example.KDT_bank_server_project2.manager.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ChatMessageService {
    @Autowired
    private ChatMessageRepository chatMessageRepository;
    @Autowired
    private ChatRoomRepository chatRoomRepository;
    @Autowired
    private UserRepository userRepository;

    public ChatMessage saveMessage(String senderId, String roomUuid, String content, ChatMessage.MessageType type, String receiverId ){
        user sender = userRepository.findByUserId(senderId)
                .orElseThrow(()-> new RuntimeException("발신자 찾을 수 없음"));
        ChatRoom room = chatRoomRepository.findByroomUuid(roomUuid);
        ChatMessage message = new ChatMessage(senderId, roomUuid, content, type, receiverId);
        return chatMessageRepository.save(message);
    } // 메시지 저장

    @Transactional(readOnly = true)
    public List<ChatMessage> getRoomMessages(String roomUuid){
        return chatMessageRepository.findByRoomUuidOrderBySentAtAsc(roomUuid);

    } // 과거 메시지 가져오기.
    @Transactional(readOnly = true)
    public List<ChatMessage> searchMessages(String roomUuid, String keyword){
        return chatMessageRepository.searchMessageByContent(roomUuid,keyword);
    } // 키워드로 메시지 찾기

    public void sendMessageWithType(String roomId, String content, String type){

    }

}
