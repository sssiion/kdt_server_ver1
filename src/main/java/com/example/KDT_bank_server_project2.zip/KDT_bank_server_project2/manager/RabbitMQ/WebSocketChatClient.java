package com.example.KDT_bank_server_project2.manager.RabbitMQ;

import com.example.KDT_bank_server_project2.manager.DTO.ChatMessageDto;
import com.example.KDT_bank_server_project2.manager.Entity.ChatMessage;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.Transport;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

public class WebSocketChatClient {
    private StompSession stompSession;
    private String severUrl = "ws://localhost:8080/ws";

    private String userId; // 로그인 시 설정

    public WebSocketChatClient(String userId) {
        this.userId = userId;
    }

    public void connect(Consumer<String> messageHandler){

            List<Transport> transports = new ArrayList<>();
            transports.add(new WebSocketTransport(new StandardWebSocketClient()));
            SockJsClient sockJsClient = new SockJsClient(transports);

            WebSocketStompClient stompClient = new WebSocketStompClient(sockJsClient);
            stompClient.setMessageConverter(new MappingJackson2MessageConverter());

            StompSessionHandler  sessionHandler =  new MyStompSessionHandler(messageHandler);
            stompSession = stompClient.connectAsync(severUrl, sessionHandler).join();

    }
    public void sendMessage(String roomId, String content, String receiver){
        ChatMessageDto message = new ChatMessageDto();
        message.setRoomId(roomId);
        message.setContent(content);
        message.setreceiverId(receiver);
        message.setType("CHAT");
        message.setSender(userId);

        stompSession.send("/app/chat.sendMessage", message);

    }
    public void sendChatMessage(String roomId, String content){
        sendMessageWithType(roomId, content, "CHAT");
    }
    public void sendJoinMessage(String roomId){
        sendMessageWithType(roomId, userId+"님이 입장", "JOIN");
    }
    public void sendLeaveMessage(String roomId){
        sendMessageWithType(roomId, userId +"님이 퇴장","LEAVE");
    }
    private void sendMessageWithType(String roomId, String content,String type){
        ChatMessageDto message = new ChatMessageDto();
        message.setRoomId(roomId);
        message.setContent(content);
        message.setType(type);
        message.setSender(userId);

        stompSession.send("/app/chat.sendMessage", message);
    }
}
