package com.example.KDT_bank_server_project2.manager.DTO;

public class UserLoginDto {

    private String userId;
    private String password;

    public UserLoginDto(String userId, String password){
        this.userId = userId;
        this.password = password;

    }
    public String getUserId() { return userId;  }
    public void setUserId(String userId) { this.userId = userId; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }


}
