package com.example.KDT_bank_server_project2.manager.RabbitMQ;

import org.springframework.messaging.simp.stomp.*;

import java.lang.reflect.Type;
import java.util.function.Consumer;

public class MyStompSessionHandler extends StompSessionHandlerAdapter {
    private Consumer<String> messageHandler;

    public MyStompSessionHandler(Consumer<String> messageHandler){
        this.messageHandler = messageHandler;
    }
    @Override
    public void afterConnected(StompSession session , StompHeaders connectedHeaders){
        System.out.println("afterConnected" + session.getSessionId());

        session.subscribe("/topic/chat", new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return String.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                messageHandler.accept((String) payload);
            }
        });

    }

    @Override
    public void handleTransportError(StompSession session, Throwable exception){
        System.err.println("전송 오류" + exception.getMessage());
        exception.printStackTrace();
    }
}
