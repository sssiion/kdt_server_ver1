package com.example.KDT_bank_server_project2.manager.Controller;


import com.example.KDT_bank_server_project2.manager.DTO.UserLoginDto;
import com.example.KDT_bank_server_project2.manager.DTO.UserRegisterDto;
import com.example.KDT_bank_server_project2.manager.DTO.UserResponseDto;
import com.example.KDT_bank_server_project2.manager.Entity.user;
import com.example.KDT_bank_server_project2.manager.Service.UserService;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // json/xml 데이터를 직접 반환하는데 주로 사용하면 rest API 개발 방식
@RequestMapping("/api/users")
public class userController {
    @Autowired // spring이 자동으로 userservice 객체를 생성해서 주입
    // 객체 생성, 필요한 의존성 함께 주입, controller 자동 연결
    private UserService userService;

    @PostMapping("/register")
    //REquestBody 클라이언트가 보낸 JSON 데이터를 java 객체로 자동 변환하는 어노테이션
    public ResponseEntity<?> registerUser(@RequestBody UserRegisterDto dto){
        try{
            user user = userService.register(
                    dto.getUserName(),
                    dto.getPassword(),
                    dto.getUserPhone()

            );
            return ResponseEntity.ok("회원가입 성공" + user.getUserId());
        }catch (IllegalArgumentException e){
            return ResponseEntity.badRequest().body("회원가입 실패" + e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UserLoginDto dto){
        try{
            user user = userService.login(dto.getUserId(), dto.getPassword());
            return ResponseEntity.ok("로그인 성공" + user.getUserName());
        }catch(IllegalArgumentException e){
            return ResponseEntity.status(401).body("로그인 실패: "+ e.getMessage());
        }
    }
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestBody UserLoginDto dto){
        userService.logoutUser(dto.getUserId());
        return ResponseEntity.ok("로그아웃 성공");

    }
    //사용자 정보 조회
    @GetMapping("/{userId}")
    public ResponseEntity<?> getUser(@PathVariable String userId){
        try{
            user user = userService.findByUserId(userId);
            return ResponseEntity.ok(user);
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/search")
    public ResponseEntity<List<UserResponseDto>> searchUsers(@RequestParam String keyword){
        List<user> users = userService.findByUserIdContaining(keyword);
        List<UserResponseDto> response = users.stream()
                .map(UserResponseDto::new)
                .toList();
        return ResponseEntity.ok(response);

    }



}
