package com.example.KDT_bank_server_project2.manager.Controller;

import com.example.KDT_bank_server_project2.manager.DTO.ChatMessageDto;
import com.example.KDT_bank_server_project2.manager.Entity.ChatMessage;
import com.example.KDT_bank_server_project2.manager.Entity.user;
import com.example.KDT_bank_server_project2.manager.Service.ChatMessageService;
import com.example.KDT_bank_server_project2.manager.Service.UserService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller // html 페이지 반환하는데 사용 , 전통적인 웹 애플리케이션 방식
//템플릿 엔진으로 HTMl을 생성해서 보여줌
public class ChatController {
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private ChatMessageService chatMessageService;

    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    // pyload : websocket 메시지 통신에  사용하고 STOMP 메시지임
    // RequestBody : REST API에 사용 HTTP 요청 , HTTP body에 담아서 보낸 Json. xml 데이터를  java 객체로 변환
    public void  sendMessage(@Payload ChatMessageDto dto){

        chatMessageService.saveMessage(dto.getUserId(), dto.getRoomId(), dto.getContent(), ChatMessage.MessageType.fromString(dto.getType()),dto.getreceiverId()); // 메시지를 데이터 베이스에 저장
        rabbitTemplate.convertAndSend("chat.exchange", "chat.message",dto); //exchate명, routing key, 실제 데이터
    }
}
