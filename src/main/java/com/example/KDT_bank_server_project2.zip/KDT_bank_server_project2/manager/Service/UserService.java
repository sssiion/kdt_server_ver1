package com.example.KDT_bank_server_project2.manager.Service;

import com.example.KDT_bank_server_project2.manager.Entity.user;
import com.example.KDT_bank_server_project2.manager.Repository.UserRepository;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;

    public user register(String name, String password, String userPhone){

        user user = new user(generateUniqueUserId(), name, password, userPhone);
        return userRepository.save(user);
    } // 유저 생성
    public user login(String userId, String password){

        user user =  userRepository.findByuserIdAndPassword(userId, password)
                .orElseThrow(() -> new IllegalArgumentException("아이디 또는 비밀번호가 다릅니다"));
        user.setOnline();
        return user;
    }// 유저 로그인.
    public void logoutUser(String userId){
        userRepository.updateOnlineStatus(userId, false);

    } // 유저 로그아웃
    @Transactional(readOnly = true)  // 데이터 베이스 트랜잭션을 자동으로 관리해주는 spring (트랜잭션 : 모든 작업이 성공, 모든 작업 실패 단위)
    public user findByUserId(String userId){
        return userRepository.findByUserId(userId)
                .orElseThrow(()-> new IllegalArgumentException("사용자를 찾을 수 없습니다" + userId));
    } // 사용자 Id 로 찾기
    // orElesThrow : optional 객체에서 사용하는 메서드로 값이 잇으면 그값 반환, 없으면 예외를 던져라

    // 온라인 사용자 목록
    @Transactional(readOnly = true)
    public List<user> getOnlineUsers(){
        return userRepository.findByIsOnlineTrue();
    }


    @Transactional(readOnly = true)
    //아이디 난수 생성
    public String generateUniqueUserId(){
        String userId;
        do{
            userId= RandomStringUtils.randomAlphanumeric(6);
        }while(userRepository.existsByUserId(userId));
        return userId;
    }



    // 모든 유저 리턴
    @Transactional(readOnly = true)
    public List<user> getAllUsers(){
        return userRepository.findAll();
    }

    public List<user> findByUserIdContaining(String keyword) {
        return userRepository.findByUserIdContaining(keyword);
    }
}
