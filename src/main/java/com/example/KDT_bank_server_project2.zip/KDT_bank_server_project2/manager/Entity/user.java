package com.example.KDT_bank_server_project2.manager.Entity;

import org.apache.commons.lang3.RandomStringUtils;
import jakarta.persistence.*; //

import java.time.LocalDateTime;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;

@Entity //JPA에게 user 클래스를 DB 테이블과 매핑해줘
@Table(name="users") // 실제 DB 에서는 user 테이블을 사용해
public class user {
    @Id  // 이 필드가 primary key라고 JPA에게 알림
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 자동 증가 설정
    private Long id;

    @Column(name="user_authority")
    private String user_authority ="USER";
    //권한 유무

    @Column(name="user_phone", unique = true)
    private String userPhone;

    @Column(name="user_name", unique = true)
    private String userName;

    @Column(name = "user_id", unique = true, nullable = false)
    private String userId;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "is_online")
    private Boolean isOnline = false;

    @Column(name = "create_at")
    private LocalDateTime createAt;

    @ElementCollection
    @CollectionTable(name = "user_joined_rooms", joinColumns = @JoinColumn(name = "user_id"))
    @MapKeyColumn(name = "room_id")
    @Column(name = "room_name")
    private Map<String, String> joinedRooms = new HashMap<>();

    @PrePersist
    protected void onCreate() {
        createAt = LocalDateTime.now();
    }

    public user(){ }

    public user(String userId, String name, String password, String userPhone){
        this.userId=  userId;
        this.userName = name;
        this.password = password;
        this.userPhone = userPhone;
        this.user_authority = "USER";


        this.isOnline = false;
    }
    public boolean checkPassword(String password){
        return this.password != null && this.password.equals(password);
    }

    public void setOnline(){
        this.isOnline = true;
    }
    public void setOffline(){
        this.isOnline = false;
    }



    public boolean isOnline() { return isOnline; }

    public void joinedRooms(String roomId, String roomName){
        this.joinedRooms.put(roomId,roomName );
    }
    public void leaveRoom(String roomId){
        joinedRooms.remove(roomId);
    }
    public  Map<String, String> getJoinedRooms(){ return joinedRooms; }

    public String getUserAuthority() { return user_authority; }
    public void setUserAuthority(String user_authority) { this.user_authority = user_authority; }

}
