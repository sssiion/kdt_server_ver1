package com.example.KDT_bank_server_project2.manager.DTO;

public class CreateRoomDto {
    private String roomName;
    private String userId;

    public CreateRoomDto(){
        this.roomName = roomName;
        this.userId = userId;

    }
    public String getRoomName() { return  roomName; }
    public void setRoomName(String roomName) { this.roomName = roomName; }

    public String getuserId() { return userId; }
    public void setuserId(String roomId) { this.userId = roomId; }
}
