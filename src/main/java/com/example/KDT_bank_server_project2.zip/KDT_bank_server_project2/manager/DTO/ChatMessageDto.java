package com.example.KDT_bank_server_project2.manager.DTO;

import com.example.KDT_bank_server_project2.manager.Entity.ChatMessage;

import java.time.LocalDateTime;

public class ChatMessageDto {
    private String roomId;
    private String userId;
    private String content;
    private String receiverId;
    private String type;

    public ChatMessageDto(){}
    public ChatMessageDto(String senderId, String roomId, String content, String type, String receiverId) {
        this.roomId = roomId;
        this.userId = senderId;
        this.type = type;
        this.content = content;
        this.receiverId = receiverId;

    }


    public String getreceiverId() { return receiverId; }
    public void setreceiverId(String senderId) { this.receiverId = senderId; }

    public String getRoomId() { return roomId; }
    public void setRoomId(String roomId) { this.roomId = roomId; }

    public String getUserId() { return userId; }
    public void setSender(String userId) { this.userId = userId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }


    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }


}
