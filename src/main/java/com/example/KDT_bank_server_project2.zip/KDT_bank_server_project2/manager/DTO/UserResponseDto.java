package com.example.KDT_bank_server_project2.manager.DTO;

import com.example.KDT_bank_server_project2.manager.Entity.user;

public class UserResponseDto {
    private String userId;
    private String userName;
    private Boolean isOnline;

    public UserResponseDto(user user) {
        this.userId = user.getUserId();
        this.userName = user.getUserName();
        this.isOnline = user.isOnline();
    }





}
